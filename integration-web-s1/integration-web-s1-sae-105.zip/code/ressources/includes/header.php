<nav class="navigation-principale">
    <ul>
        <li>
            <a href="index.php">ACCUEIL</a>
        </li>
        <li>A PROPOS</li>
        <li>LIEUX DE VIE</li>
        <li>CONTACT</li>
    </ul>
</nav>

<header class="bulle">
    <article class="titre">
        <p class="txt-grand">
            <span>Bachelor</span>
            <span>Universitaire de</span>
            <span>Technologie</span>
        </p>
        <p class="txt-petit">
            <span>Métiers du Multimédia et de</span>
            <span>l'Internet</span>
        </p>
    </article>

    <article class="bulle-icone <?php echo $couleur_bulle_classe; ?>"></article>
    <article class="bulle-icone-bordure <?php echo $couleur_bulle_classe; ?>"></article>
</header>