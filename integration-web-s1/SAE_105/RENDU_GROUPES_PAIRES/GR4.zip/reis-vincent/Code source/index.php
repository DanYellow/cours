<?php
$couleur_bulle_classe = "rose";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/BUTcoco.css">
    <link rel="icon" href="ressources\images\téléchargement.png" type="image/icon type">
</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <main class="conteneur-principal">
            
            <h1 class="titre-page"> Article sur le BUT MMI</h1>

            <section class="colonne">
                <section class="colonne-box">
                    <section class="box">

                            <img src="ressources/images/IMG_6897.png" width="600" class="logo" alt="">

                            <div>

                        <p>
                
                        </p>
                        <h1 class="texte-gras-moyen" style="padding:2rem">Développement web</h1>
                        <h1 class="texteBUTMMI2" style="padding:2rem">
                            Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML.
                            On y apprend les langages HTML et CSS, simples mais énormément pratiques.>
                            Le web ayant été pensé pour être accessible,
                            le cours enseigne également les normes d'accessibilités comme le
                            contraste des couleurs ou encore la taille des polices d'écriture.
                        </h1>

                            </div>
                    </section>
                    <section class="box">

                            <img src="ressources/images/IMG_6897.png" width="600" class="logo" alt="">

                            <div>

                        
                            <h1 class="texte-gras-moyen" style="padding:2rem">Développement web</h1>
                        <h1 class="texteBUTMMI2" style="padding:2rem">
                            Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML.
                            On y apprend les langages HTML et CSS, simples mais énormément pratiques.>
                            Le web ayant été pensé pour être accessible,
                            le cours enseigne également les normes d'accessibilités comme le
                            contraste des couleurs ou encore la taille des polices d'écriture.
                        </h1>

                            </div>
                    </section>
                    <section class="box">

                            <img src="ressources/images/IMG_6897.png" width="600" class="logo" alt="">

                            <div>

                        
                            <h1 class="texte-gras-moyen" style="padding:2rem">Développement web</h1>
                        <h1 class="texteBUTMMI2" style="padding:2rem">
                            Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML.
                            On y apprend les langages HTML et CSS, simples mais énormément pratiques.>
                            Le web ayant été pensé pour être accessible,
                            le cours enseigne également les normes d'accessibilités comme le
                            contraste des couleurs ou encore la taille des polices d'écriture.
                        </h1>

                            </div>
                    </section>
                </section>
            
                <a class="jpo-banniere" href="https://www.cyu.fr/salons-journee-portes-ouvertes"> 
                    <img src="ressources/images/logo-cyu-blanc.png" width="200" class="logo" alt="">

                    <section class="textes">
                        <p class="txt-petit">Journée portes <br /> ouvertes</p>
                        <p class="txt-petit">
                            12/02/2022, <br />
                            de 10h à 17h
                        </p>
                        <p class="en-savoir-plus">EN SAVOIR PLUS</p>

                    
                    </section>
                </a>
                </section>

        </main>

    </section>

    <?php require_once('./ressources/includes/footer.php'); ?>

</body>

</html>