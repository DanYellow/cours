<?php
   $couleur_bulle_classe = "rose";


   $nom='';
   $prenom='';
   $mail='';
   $messages='';

    
   if (!empty( $_POST['nom']) && !empty( $_POST['prenom']) && !empty( $_POST['mail']) && !empty( $_POST['messages']))
   {
      echo '<div class="bandeau-vert">Tout est bon !</div>';
   }
   elseif (!empty( $_POST['nom']) || !empty( $_POST['prenom']) || !empty( $_POST['mail']) || !empty( $_POST['messages']))
   {
      echo '<div class="bandeau-rouge">Information(s) manquente(s)</div>';
   }
   else
   {
      
   }
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/footer.css">
    <link rel="stylesheet" href="ressources/css/reponse.css">
    <link rel="icon" href="ressources\images\téléchargement.png" type="image/icon type">
    
</head>
   
   <body>
   <section class="conteneur-1280">

   
   <?php require_once('./ressources/includes/header.php'); ?>
      <?php 
        
        if (!empty( $_POST['nom']) && !empty( $_POST['prenom']) && !empty( $_POST['mail']) && !empty( $_POST['messages']))
            {
               require_once('./ressources/includes/reponse.php');
            }
      ?>
   
   <main class="conteneur-principal">
         <h1 class="titre-page">Plus d'infos sur la formation ?<br/>
            Contactez-nous !</h1>
                            
                    <section class="textes">
                        <p class="txt-petit">La formation s'ouvre à tous les bacheliers, pour rappel. Avoir des connaissances en programmation, 
                            design ou encore audiovisuel n'est pas obligatoire mais reste un bon atout, car il faut aimer la curiosité dans cette formation pluridisciplinaire. 
                            Il est également possible de faire la formation après une reprise d'études ou une réorientation. </p>
                    
            <h1 class="titre-page">Nous contacter en ligne</h1>
                    
      <form name="reponse" method="post" action="">
         <fieldset>
            
            
            <div class="txt-gras">Nom*</div>
            <div class="champ">
               <input type="text" name="nom" 
               style="border:solid thick black; border-radius: 2px; border-width:1px; padding-left:1px; padding-top:15px; padding-bottom:15px; margin:2px; width:500px;">
               
            </div>
            
            <div class="txt-gras">Prénom*</div>
            <div class="champ">
               <input type="text" name="prenom"
               style="border:solid thick black; border-radius: 2px; border-width:1px; padding-left:1px; padding-top:15px; padding-bottom:15px; margin:2px; width:500px;">
               
            </div>
            
            <div class="txt-gras">Mail*</div>
            <div class="champ">
               <input type="text" name="mail" 
               style="border:solid thick black; border-radius: 2px; border-width:1px; padding-left:1px; padding-top:15px; padding-bottom:15px; margin:2px; width:500px;">
               
            </div>
            
            <div class="txt-gras">Message*</div>
            <div class="champ">
               <input type="text" name="messages" 
               style="border:solid thick black; border-radius: 2px; border-width:1px; padding-left:1px; padding-top:15px; padding-bottom:15px; margin:2px; width:500px;">
               
            </div>   

            <div class="txt-gras">Je suis*</div>
            <div class="champ">
            <input type="checkbox" name="un" value="1"  
                    <?php if (isset( $_POST['un'])); ?>>Je ne souhaite pas le préciser
                
                <input type="checkbox" name="deux" value="2" 
                    <?php if (isset( $_POST['deux'])); ?>>Étudiant / Étudiantes
                
                <input type="checkbox" name="trois" value="3" 
                    <?php if (isset( $_POST['trois'])); ?>>Parent

                <input type="checkbox" name="quatre" value="4" 
                    <?php if (isset( $_POST['quatre'])); ?>>Autre
            </div>
            <div class="champ">
                <input type="submit" name="envoyer" value="ENVOYER" class="rectangle-envoyer">
            </div>
        </fieldset>
      </form>

         <br><h1 class="titre-page">Nous contacter par courrier</h1>
            <section class="textes">
            <p class="txt-petit">IUT de Cergy-Pontoise,<br>
            Département Métiers du Multimédia et de l'Internet (MMI)<br>
            34 Bis Boulevard Henri Bergson<br>
            95200 Sarcelles</p>
            </section>
            
            <?php require_once('./ressources/includes/footer.php'); ?>
   </main>
   </body>
</html>