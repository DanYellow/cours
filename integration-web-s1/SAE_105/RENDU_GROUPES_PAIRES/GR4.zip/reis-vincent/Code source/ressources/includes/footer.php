<link rel="stylesheet" href="ressources/css/footer.css">


<div class="footer">
        <h1 class="text-petit">Certains textes sont issus de Wikipédia</h1>
        <h1><a href="https://www.facebook.com/CYCergyParisUniversite/">Facebook</a> 
        <a href="https://twitter.com/universitecergy">Twitter</a> 
        <a href="https://www.cyu.fr/">Université CY Paris Université</a> • Remonter</h1>
        <h1>© 2013-2021 - BUT MMI - CY Paris Université</<h1>>
        <h1><img src="ressources\images\logocyu.png" alt="logocyu" height="100"></h1>
    
</div>
</article> 
</header>