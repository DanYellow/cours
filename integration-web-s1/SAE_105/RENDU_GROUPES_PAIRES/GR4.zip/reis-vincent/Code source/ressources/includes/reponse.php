<header class="conteneur-1480">
<article class="reponse">
<h1 class="reponse">
<?php

$nom= $_POST["nom"];
$prenom= $_POST["prenom"];
$mail= $_POST["mail"];
$messages= $_POST["messages"];

   if (!empty( $_POST['nom']) && !empty( $_POST['prenom']) && !empty( $_POST['mail']) && !empty( $_POST['messages']) && !empty($_POST["un"]))
   {
      echo "Bonjour $nom $prenom, vous ne souhaiter pas préciser ce que vous êtes, votre e-mail est bien $mail et vous nous avez envoyez ceci comme message : $messages";
   }
   elseif (!empty( $_POST['nom']) && !empty( $_POST['prenom']) && !empty( $_POST['mail']) && !empty( $_POST['messages']) && !empty($_POST["deux"]))
   {
      echo "Bonjour $nom $prenom, vous êtes un ou une étudiant(e), votre e-mail est bien $mail et vous nous avez envoyez ceci comme message : $messages";
   }
   elseif (!empty( $_POST['nom']) && !empty( $_POST['prenom']) && !empty( $_POST['mail']) && !empty( $_POST['messages']) && !empty($_POST["trois"]))
   {
      echo "Bonjour $nom $prenom, vous êtes un parent, votre e-mail est bien $mail et vous nous avez envoyez ceci comme message : $messages";
   }
   else
   {
      echo "Bonjour $nom $prenom, votre e-mail est bien $mail et vous nous avez envoyez ceci comme message : $messages";
   }
   
?>
</h1>
</article>
</header>