<nav class="navigation-principale">
    <ul>
        <li> <a href="/SAE/index.php" style="color:#000000; text-decoration: none">ACCUEIL</a> </li>
        <li> <a href="/SAE/page2.php" style="color:#000000; text-decoration: none">A PROPOS</a> </li>
        <li> <a href="/SAE/page3.php" style="color:#000000; text-decoration: none">CONTACT</a> </li>
        <li> <a href="/SAE/page4.php" style="color:#000000; text-decoration: none">SUR LES MÉDIAS</a> </li>
        <li> <a href="/SAE/page5.php" style="color:#000000; text-decoration: none">LES DÉBOUCHÉS</a> </li>
    </ul>
</nav>

<header class="bulle">
    <article class="titre">
        <h1 class="txt-grand">
            <span>Bachelor</span>
            <span>Universitaire de</span>
            <span>Technologie</span>
        </h1>
        <h2 class="txt-petit">
            <span>Métiers du Multimédia et de</span>
            <span>l'Internet</span>
        </h2>
    </article>

    <article class="bulle-icone <?php echo $couleur_bulle_classe; ?>"></article>
    <article class="bulle-icone-bordure <?php echo $couleur_bulle_classe; ?>"></article>
</header>