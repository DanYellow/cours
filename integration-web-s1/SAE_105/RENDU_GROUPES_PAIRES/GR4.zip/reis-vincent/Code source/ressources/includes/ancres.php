<link rel="stylesheet" href="ressources/css/ancres.css">


<div class="ancres">
             <h1><a href="#Presentation" style="color:#03886D">Présentation</a></h1>
             <h1><a href="#SAE" style="color:#03886D">SAÉ</a> </h1>
             <h1><a href="#Exemple" style="color:#03886D">Exemples de SAÉ</a> </h1>
</div>