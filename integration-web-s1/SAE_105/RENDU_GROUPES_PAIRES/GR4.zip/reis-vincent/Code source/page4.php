<?php
    $couleur_bulle_classe = "rose";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Médias</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/oui.css">
    <link rel="stylesheet" href="ressources/css/oui2.css">
    <link rel="icon" href="ressources\images\téléchargement.png" type="image/icon type">

</head>
<body>
    <section class="conteneur-1280">
    <?php require_once('./ressources/includes/header.php'); ?>
<main>
<div class="all-video">
<section class="video1">
    <p>La nouvelle réforme: le BUT MMI</p>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/oiEbQF7qfBU" 
    title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
</section>
    
<section class="video">
    <p>Pourquoi étudier à l'IUT CYU ?</p>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/SyjF4h2Zb7Q" 
    title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
</section>

<section class="video">
    <p>Job interview en anglais au département MMI</p>
    <iframe width="560" height="315" src="https://www.youtube.com/embed/t72pdxpNjyc" 
    title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
</section>    

<section class="video">
    <p>L'importane de l'IUT dans les études supérieures</p>
    <iframe class="S"  width="560" height="315" src="https://www.youtube.com/embed/xD4wshE0hEg" 
    title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
</section>
</div>
    
<?php require_once('./ressources/includes/footer.php'); ?>
    
</main>
</body>
</head>