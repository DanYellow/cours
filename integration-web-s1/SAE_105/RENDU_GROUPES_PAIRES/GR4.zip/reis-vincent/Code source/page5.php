<?php
    $couleur_bulle_classe = "rose";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Les débouchés</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/oui.css">
    <link rel="icon" href="ressources\images\téléchargement.png" type="image/icon type">

</head>
<body>
    <section class="conteneur-1280">
    <?php require_once('./ressources/includes/header.php'); ?>
        <main class="informations-conteneur">
            <div>
            <h1 class="titre-page">Les débouchés professionnels</h1>

            <p class="texte-pres"> Il existe de nombreux débouchés suite au BUT MMI. Nous vous proposons quelques exemples mais bien sûr le choix est en réalité très large. 
                Pour plus d'informations nous vous conseillons le site Onisep. </p>

            <section class="debouches">
                <div class="texte-debouches">
                <p class="titre"> Animateur 2D/3D</p>
            
                <p class="informations">Maître du mouvement, l'animateur 2D et 3D est d'abord un artiste, 
                    spécialiste des images de synthèse. Cinéma, jeux vidéo, publicité ou site Internet, les projets d'animation ne manquent pas, 
                    et attirent de plus en plus de jeunes. L'animateur 2D part du dessin, puis utilise des logiciels pour donner vie à des personnages.
                    L'animateur 3D ne dessine pas puisque les personnages qu'il anime sont en images de synthèse et en volume. Partant d'un « squelette »
                    habillé de texture (peau, vêtements), il transmet les coordonnées des positions de départ et d'arrivée à l'ordinateur selon le déplacement
                    souhaité, grâce à des logiciels spécifiques qu'il doit maîtriser parfaitement. L'animation exige également le sens artistique et beaucoup de pratique.</p>
                </div>
                <figure class="image-debouches">
                <img src="https://www.esma-3d.ca/wp-content/uploads/2018/03/atelier-toulouse-2_528681609.jpeg" alt="">
                </figure>
            </section>

            <section class="debouches reverse">
                <div class="texte-debouches">
                <p class="titre"> Intégrateur Web</p>

                <p class="informations">Travaillant dans une agence web, en indépendant ou dans une ESN (entreprise de services du numérique),
                    l'intégrateur web assemble différents éléments (textes, images, sons, vidéos, animations) en vue de la
                    construction d'un site Internet.L'intégrateur web est chargé de monter les pages d'un site en réunissant l'ensemble des éléments décidés par le chef de projet ou le w
                    bmaster : textes, images, liens hypertextes, tableaux, etc. Son travail se situe entre celui du webdesigner et celui du développeur. Doté
                    d'une bonne connaissance des langages informatiques, il possède aussi un sens artistique. Dans les grosses structures, il travaille sous
                    la responsabilité d'un chef de production (ou d'un webmestre) qui assure la coordination de son travail avec les différentes équipes
                    (éditoriale, graphique, commerciale, informatique) ainsi qu'avec les éventuels autres intégrateurs. </p>     
                </div>
                <figure class="image-debouches">
                <img src="https://cdn.1min30.com/wp-content/uploads/2016/08/shutterstock_275000441-1.jpg" alt="">
                </figure>
            </section>

            <section class="debouches">
                <div class="texte-debouches">
                <p class="titre">Concepteur Multimédia </p>

                <p class="informations">Ce spécialiste de l'interactivité crée des produits multimédias en mêlant sons, textes et images,
                encollaboration avec des graphistes, des auteurs, des développeurs et des webdesigners. Le concepteur multimédia accompagne la naissance d'un produit multimédia : 
                cédérom éducatif ou commercial, jeu vidéo, DVD ou site Internet. Il en détermine l'architecture générale, c'est-à-dire qu'il organise et met en scène les différents contenus (textes, musiques, 
                déos, animations et images) pour les rendre attractifs. Puis il conçoit les moyens de navigation qui permettent d'accéder aux infomartions. </p>           
                </div> 
                <figure class="image-debouches">
                <img src ="https://www.learnprogress.mu/wp-content/uploads/2021/01/shutterstock_1599273019.jpg" alt=""> 
                </figure>
            </section>

            <section class="debouches reverse" >
                <div class="texte-debouches">
                <p class="titre"> Community Manager</p>

                <p class="informations">Garant de la présence et de la (bonne !) réputation d'une marque ou d'une entreprise sur les réseaux sociaux, le community manager anime
                    une communauté d'internautes, publie des tweets, répond aux questions sur le Net, alimente la page Facebook... Le community manager doit fédérer le plus possible d'internautes via les forums, les réseaux sociaux et professionnels. 
                    Expert de la Toile, il est en veille permanente pour gérer l'image de son client ou de son entreprise sur le Net et rapprocher la marque du consommateur. 
                    Pour cela, il anime des forums, poste des vidéos, alimente la page Facebook ou répond aux questions posées sur le site Internet de l'entreprise. Toujours connecté, il est à l'aise avec l'univers de l'Internet.</p>
                </div>
                <figure class="image-debouches">
                <img src ="https://assets-fr.imgfoot.com/media/les-community-manager-sont-devenus-indispensables-a-la-communication-des-clubs_269950.jpg" alt=""> 
                </figure>
            </section>

             <section>
            <p class ="informations"> En savoir plus sur</p>
            <img class="onisep" src ="https://www.apel-dordogne.com/wp-content/uploads/2018/03/LOGO-ONISEP.jpg" alt="">
            
            </section>

    </section> 
    
    <?php require_once('./ressources/includes/footer.php'); ?>       
</main>
</body>
</html>

