<?php
$couleur_bulle_classe = "vert";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYU/Débouchés</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/debouche.css">
    <link rel="stylesheet" href="ressources/css/footer.css">
    <!--  lien pour la favicon   -->
    <link rel="apple-touch-icon" sizes="180x180" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="32x32" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="90x10" href="ressources/images/logo-iut.png">
    <link rel="manifest" href="ressources/images/logo-iut.png">

</head>

<body>
    <section class="conteneur-1280">


        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->
        <?php require_once('./ressources/includes/header.php'); ?>

        <main class="conteneur-principal">
            <table class="table-metiers">
                <thead>
                    <tr>
                        <th> BUT MMI</th>
                        <th>BTS TC</th>
                        <th>Formation pilote</th>
                        <th>GEII</th>
                    </tr>
                </thead>

                <tbody>
                    <tr>
                        <td>Designer, Concepteur Web, Journaliste Web, Directeur Artistique, chef de projet</td>
                        <td> Vendeur, Poste polyvalent en entreprise, agent Immobilier, assistant commercial, manager</td>
                        <td>Aviation, Pilote de ligne, Pilote de brousse</td>
                        <td>Etudes de developpement, Evenementiel ,Informaticien industriel, agro-industrie, électrotechnicien </td>
                    </tr>
                    <tr>
                        <td>Concepteur Web, Game Designer, monteur video web, community manager</td>
                        <td>Relationnel avec la clientele, Representant ou PDG, chef de rayon, chef de ventes </td>
                        <td>Pilote de ligne, Surveillance aerienne</td>
                        <td> Robotique, Specialiste informatique, électrotechniques et communication,industrie chimique</td>

                    </tr>

                </tbody>

            </table>


        </main>


    </section>

    <?php require_once('./ressources/includes/footer.php'); ?>


</body>


</html>