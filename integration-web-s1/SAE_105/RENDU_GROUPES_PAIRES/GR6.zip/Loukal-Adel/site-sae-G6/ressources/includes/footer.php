<footer>


    <div id="footer">

        <h4> Certains textes sont issus de Wikipédia </H4>
        <a target="_blank" class="lien" href="https://fr-fr.facebook.com/CYCergyParisUniversite/"> Facebook </a>
        <a target="_blank" class="lien" href="https://twitter.com/universitecergy?lang=fr"> Twitter </a>
        <a target="_blank" class="lien" href="https://www.cyu.fr/"> CY Paris Université </a>


        <h4>© 2013–2021 - BUT MMI - CY Paris Université • Remonter</h4>
        <img class="img-footer" src="ressources/images/logo-cyu-couleur.svg">


    </div>

</footer>