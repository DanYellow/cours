<link rel="stylesheet" href="ressources/css/navigation.css">

<nav class="navigation-principale">
    <ul>
        <li> <a class="navigation" href="index.php"> ACCUEIL </a> </li>
        <li> <a class="navigation propos" href="A_Propos.php"> A PROPOS </a> </li>
        <li> <a class="navigation contact" href="contact.php"> CONTACT </a> </li>
        <li> <a class="navigation medias" href="medias.php"> SUR LES MEDIAS </a> </li>
        <li> <a class="navigation debouche" href="debouche.php"> DÉBOUCHÉS</a> </li>
    </ul>
    </ul>
</nav>

<header class="bulle">
    <article class="titre">
        <h1 class="txt-grand">
            <span>Bachelor</span>
            <span>Universitaire de</span>
            <span>Technologie</span>
        </h1>
        <h2 class="txt-petit">
            <span>Métiers du Multimédia et de</span>
            <span>l'Internet</span>
        </h2>
    </article>

    <article class="bulle-icone <?php echo $couleur_bulle_classe; ?>"></article>
    <article class="bulle-icone-bordure <?php echo $couleur_bulle_classe; ?>"></article>
</header>