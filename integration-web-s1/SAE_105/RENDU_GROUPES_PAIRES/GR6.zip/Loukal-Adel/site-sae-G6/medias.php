<?php
$couleur_bulle_classe = "bleu";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYU/médias</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/medias.css">
    <link rel="stylesheet" href="ressources/css/footer.css">
    <!--  lien pour la favicon   -->
    <link rel="apple-touch-icon" sizes="180x180" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="32x32" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="90x10" href="ressources/images/logo-iut.png">
    <link rel="manifest" href="ressources/images/logo-iut.png">

</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->
        <h4 class="h4-titre">
            Les actualités et évènements important du BUT et de l'IUT CY
            Paris Université dans les médias
        </h4>

        <div class="container">
            <main class="grid">

                <article>
                    <p>La nouvelle réforme: le BUT MMI</p>
                    <iframe width="400" height="250" src="https://www.youtube.com/embed/oiEbQF7qfBU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </article>


                <article>
                    <p>Pourquoi étudier à l'IUT CYU</p>
                    <iframe width="400" height="250" src="https://www.youtube.com/embed/SyjF4h2Zb7Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </article>

                <article>
                    <p>L'importance de l'IUT dans les études supérieures</p>
                    <iframe width="400" height="250" src="https://www.youtube.com/embed/xD4wshE0hEg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </article>

                <article>
                    <p ">Job interview en anglais au département MMI</p>
            <iframe width=" 400" height="250" src="https://www.youtube.com/embed/t72pdxpNjyc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </article>

            </main>
        </div>
    </section>

    <?php require_once('./ressources/includes/footer.php'); ?>
</body>

</html>