<?php
$couleur_bulle_classe = "rose";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYU/accueil</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/footer.css">
    <!--  lien pour la favicon   -->
    <link rel="apple-touch-icon" sizes="180x180" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="32x32" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="90x10" href="ressources/images/logo-iut.png">
    <link rel="manifest" href="ressources/images/logo-iut.png">


</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->

        <main class="conteneur-principal">
            <h1 class="titre-article">Articles sur le BUT MMI</h1>



            <section class="liste-article">
                <section>

                    <div class="article">
                        <img src="ressources/images/IMG_6897.png" alt="">
                        <h1 class="tire-article">Développement web</h1>
                        <p>Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML. On y apprend les
                            langages HTML et CSS, simples mais énormément pratiques. <br> Le web ayant été pensé pour être accessible, le
                            cours enseigne également les normes d'accessibilités comme le contraste des couleurs ou encore la taille des
                            polices d'écriture.</p>

                    </div>

                    <div class="article">
                        <img src="ressources/images/IMG_6897.png" alt="">
                        <h1 class="tire-article">Développement web</h1>
                        <p>Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML. On y apprend les
                            langages HTML et CSS, simples mais énormément pratiques.<br> Le web ayant été pensé pour être accessible, le
                            cours enseigne également les normes d'accessibilités comme le contraste des couleurs ou encore la taille des
                            polices d'écriture.</p>

                    </div>
                    <div class="article">
                        <img src="ressources/images/IMG_6897.png" alt="image">
                        <h1 class="tire-article">Développement web</h1>
                        <p>Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML. On y apprend les
                            langages HTML et CSS, simples mais énormément pratiques.<br> Le web ayant été pensé pour être accessible, le
                            cours enseigne également les normes d'accessibilités comme le contraste des couleurs ou encore la taille des
                            polices d'écriture.</p>

                    </div>
                </section>
                <a class="jpo-banniere" href="https://www.cyu.fr/salons-journee-portes-ouvertes">
                    <img src="ressources/images/logo-cyu-blanc.png" width="200" class="logo" alt="">

                    <section class="textes">
                        <p class="txt-petit">Journée portes <br /> ouvertes</p>
                        <p class="txt-grand">
                            12/02/2022 <br />
                            de 10h à 17h
                        </p>
                        <p class="en-savoir-plus">EN SAVOIR PLUS</p>
                    </section>
                </a>
            </section>

    </section>

    <?php require_once('./ressources/includes/footer.php'); ?>

</body>

</html>