<?php
$couleur_bulle_classe = "jaune";
?>




<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYU/contact</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/contact.css">
    <link rel="stylesheet" href="ressources/css/Message.css">
    <link rel="stylesheet" href="ressources/css/footer.css">
    <!--  lien pour la favicon   -->
    <link rel="apple-touch-icon" sizes="180x180" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="32x32" href="ressources/images/logo-iut.png">
    <link rel="icon" type="image/png" sizes="90x10" href="ressources/images/logo-iut.png">
    <link rel="manifest" href="ressources/images/logo-iut.png">

</head>

<body>
    <?php
    if (!empty($_POST)) {
        if (empty($_POST['Prénom']) && empty($_POST['Nom']) && empty($_POST['E-mail']) && empty($_POST['Message'])) {
            echo "<div class='message invalide'><p class='txtmsg'>Message invalide!</p></div>";
        } else {
            echo "<div class='message valide'><p class='txtmsg'>Message envoyé!</p></div>";
        }
    }
    ?>

    <section class="conteneur-1280">
        <!--Ramener le header-->
        <?php require_once('./ressources/includes/header.php'); ?>

        <div class="titre">
            <h1 class="sous-titres" id="sstitre1">Plus d'infos sur la formation ?</h1>
            <h1 class="sous-titres" id="sstitre2"> Contactez-nous !</h1>
        </div>

        <div>
            <p><span>La formation s'ouvre à tous les bacheliers,</span> pour rappel. Avoir des connaissances en programmation, design ou encore audiovisuel n'est pas obligatoire mais reste un bon atout, car il faut aimer la curiosité dans cette formation pluridisciplinaire. <span>Il est également possible de faire la formation après une reprise d'études ou une réorientation.</span></p>
        </div>


        <!--Formulaire avec uneméthode post car les données sont sensibles-->
        <!--Les données rentrées par l'utilisateur seront traités dans le fichier traitement.php-->
        <form action="" method="POST">
            <h1 class="sous-titres" id="sstitre3">Nous contacter en ligne</h1>

            <!--Titre du champ-->
            <div class="premierintitulé">
                <label for="prénom">Prénom</label>
            </div>

            <!--Champ-->
            <div>
                <input type="text" id="prénom" name="Prénom" class="contenant">
            </div>

            <!--Titre du champ-->
            <div class="intitulé">
                <label for="nom de famille">Nom de famille</label>
            </div>

            <!--Champ-->
            <div>
                <input type="text" id="nom" name="Nom" class="contenant">
            </div>

            <!--Titre du champ-->
            <div class="intitulé">
                <label for="e-mail">Adresse e-mail</label>
            </div>

            <!--Champ-->
            <div>
                <input type="email" id="mail" name="E-mail" class="contenant">
            </div>

            <!--Titre du champ-->
            <div class="intitulé">
                <label for="message">Message</label>
            </div>

            <!--Champ-->
            <div>
                <textarea id="message" name="Message" class="grandcontenant"></textarea>
            </div>

            <!--Titre des éléments à cocher-->
            <div class="dernierintitulé">
                <label for="je suis">Je suis</label>
            </div>

            <!--Chaque input correspond à un élément à cocher-->
            <div>
                <input type="radio" id="Choix 1" name="je suis" value="non-défini">
                <label for="Choix 1">Je ne souhaite pas le préciser</label>

                <input type="radio" id="Choix 2" name="je suis" value="étudiant" checked>
                <label for="Choix 2">Étudiant / Étudiante</label>

                <input type="radio" id="Choix 3" name="je suis" value="parent">
                <label for="Choix 3">Parent</label>

                <input type="radio" id="Choix 4" name="je suis" value="autre">
                <label for="Choix 4">Autre</label>
            </div>

            <!--Bouton envoyer-->
            <div class="paddingbtn">
                <button type="submit" name="Envoyer" class="btn">ENVOYER</button>
            </div>
        </form>


        <h1 class="sous-titres">Nous contacter par courrier</h1>
        <div class="paddingsstitre4">
            <p>IUT de Cergy-Pontoise,<br>
                Département Métiers du Multimédia et de l’Internet (MMI)<br>
                34 Bis Boulevard Henri Bergson<br>
                95200 Sarcelles</p>
        </div>
    </section>
    <?php require_once('./ressources/includes/footer.php'); ?>
</body>

</html>