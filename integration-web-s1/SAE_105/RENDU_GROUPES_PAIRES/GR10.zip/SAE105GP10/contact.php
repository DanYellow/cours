<?php
    if (isset($_POST['submit'])) {
        $destinataire = "helenelin03@gmail.com";
        $expediteur = $_POST['email'];
        $objet="Nouveau message";
        $prenom = $_POST["firstname"];
        $nom = $_POST['lastname'];
        $message = $firstname ." ". $lastname ." a envoyé le message suivant " . "\n\n" . $_POST['message'];

        $headers = "De:" . $expediteur;
        mail($destinataire, $objet, $message, $headers);

        if (!empty($_POST)) {
            if (isset($_POST['prenom']) && isset($_POST['nom']) && isset($_POST['email']) && isset($_POST['message']) && isset($_POST['statut'])) {
                echo '<section>
                <p class="notif-env">Message envoyé !</p>
                </section>';
            } else {
                echo 'Votre message possède une erreur !';
            }
        }
    }
    ?>

<?php
$couleur_bulle_classe = "jaune";
$page_active = "contact";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/footer.css">
    <link rel="stylesheet" href="ressources/css/contact.css">
</head>

<body>

    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <main class="conteneur-principal">
            <section class='espace-ligne'></section>
            <h1 class="titre-page">Plus d'infos sur la formation ? </h1>
            <h1 class="titre-page">Contactez-nous !</h1>

            <p><span class="paragraphe-gras">La formation s'ouvre à tous les bacheliers,</span>
                pour rappel. Avoir des connaissances en programmation, design ou encore audiovisuel n'est pas obligatoire
                mais reste un bon atout, car il faut aimer la curiosité dans cette formation pluridisciplinaire.
                <span class="paragraphe-gras">Il est également possible de faire la formation après une reprise d'études ou une réorientation.</span>
            </p>

            <section class='espace-ligne'></section>

            <section class='espace-champ'>
                <section class='espace-champ'>
                    <h1 class="titre-page">Nous contacter en ligne</h1>
                </section>

                <form action="contact.php" method="post">
                    <article>
                        <section class='espace-champ'>
                            <p><span class="paragraphe-gras"><label for="prenom">Prénom *</label></span></p>
                            <input type="text" id="firstname" name="prenom" required="" />
                        </section>

                        <section class='espace-champ'>
                            <p><span class="paragraphe-gras"><label for="nom">Nom de famille *</label></span></p>
                            <input type="text" id="lastname" name="nom" required="" />
                        </section>

                        <section class='espace-champ'>
                            <p><span class="paragraphe-gras"><label for="email">Adresse e-mail *</label></span></p>
                            <input type="email" id="email" name="email" required="" />
                        </section>

                        <section class='espace-champ'>
                            <p><span class="paragraphe-gras" rows="30" cols="80"><label for="message" maxlength>Message *</label></span></p>
                            <textarea id="message" name="message">
                        </textarea>
                        </section>

                        <section class='espace-champ'>
                            <span class="paragraphe-gras">
                                <p>Je suis:</p>
                            </span>
                        </section>
                        <article>

                            <section class='espace-champ'>
                                <section class="radio-check">
                                    <span class="radio-check">
                                        <input type="radio" id="non-precise" name="statut" value="non-precise">
                                        <label for="non-precise">Je ne souhaite pas le préciser</label>
                                    </span>

                                    <span class="radio-check b">
                                        <input type="radio" id="etudiant" name="statut" value="etudiant" checked>
                                        <label for="etudiant">Étudiant / Étudiante</label>
                                    </span>

                                    <span class="radio-check b">
                                        <input type="radio" id="parent" name="statut" value="parent">
                                        <label for="parent">Parent</label>
                                    </span>

                                    <span class="radio-check b">
                                        <input type="radio" id="autre" name="statut" value="autre">
                                        <label for="autre">Autre</label><br>
                                    </span>
                                </section>
                            </section>

                        </article>

                        <section>
                            <button type="submit" value="Envoyer"> ENVOYER </button>
                        </section>

                </form>
            </section>

            <section>
                <h1 class="titre-page contact">Nous contacter par courrier</h1>
                <p>IUT de Cergy-Pontoise, <br> Département Métiers du Multimédia et de l’Internet (MMI) <br>34 Bis Boulevard Henri Bergson <br>95200 Sarcelles<br></p>
            </section>

        </main>

        <section class='espace-champ'></section>

        <section>
            <?php require_once('./ressources/includes/footer.php'); ?>
        </section>
</body>

</html>