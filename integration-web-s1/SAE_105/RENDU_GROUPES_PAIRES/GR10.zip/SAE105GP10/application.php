<?php
$couleur_bulle_classe = "bleu";
$page_active = "application";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Télécharger l'application CYU </title>

    <link rel="stylesheet" href="ressources/css/reset.css" />
    <link rel="stylesheet" href="ressources/css/global.css" />
    <link rel="stylesheet" href="ressources/css/header.css" />
    <link rel="stylesheet" href="ressources/css/footer.css" />
    <link rel="stylesheet" href="ressources/css/accueil.css" />
    <link rel="stylesheet" href="ressources/css/application.css" />
    <link rel="stylesheet" href="ressources/css/slide.css" />
</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <main class="conteneur-principal">
            <h1 class="titre-page">Pour faciliter l'accessibilité et les échanges,
                <span class="titre-page cinq">découvrez l'application de l'IUT </span>
            </h1>

            <section class="colonne">

                <section class="liste-article">
                    <section class="bloc-img-un">
                        <a class="img-article-un">
                            <img src="ressources/images/ENT1.png" width="400px" alt="apercu"></a>
                    </section>
                </section>

                <section class="colonne-deux">
                    <section class="bloc-img-deux" a href="https://www.canva.com/design/DAE1RNPqv-o/wejY0lUXZkbzedk7Jlie6g/view?mode=prototype">
                        <h1 class="titre-bloc-deux"><a class="titre-bloc-deux lien" href="https://www.canva.com/design/DAE1RNPqv-o/wejY0lUXZkbzedk7Jlie6g/view?mode=prototype">
                                Télécharger l'application</a></h1>
                    </section>

                    <section class="bloc-img-trois">
                        <a class="img-article-deux">
                            <ul class="titre-bloc">Démarche:
                                <li class="etape">Téléchargez l'application sur le lien cliquable ci-dessus</li>
                                <li class="etape">Activez votre compte en vous connectant ou en vous inscrivant</li>
                                <li class="etape">Vous êtes maintenant libre de surfer sur l'application !</li>
                            </ul>
                        </a>
                    </section>

                </section>
            </section>

            <section>
                <p class="titre-apercu"> Aperçu de l'application </p>
            </section>

            <?php require_once('./ressources/includes/slide.php'); ?>

    </main>

    <section>
        <?php require_once('./ressources/includes/footer.php'); ?>
    </section>

</body>

</html>