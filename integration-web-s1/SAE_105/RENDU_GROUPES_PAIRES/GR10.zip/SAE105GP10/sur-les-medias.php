<?php
$couleur_bulle_classe = "rouge";
$page_active = "medias";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sur les médias</title>

    <link rel="stylesheet" href="ressources/css/reset.css" />
    <link rel="stylesheet" href="ressources/css/global.css" />
    <link rel="stylesheet" href="ressources/css/header.css" />
    <link rel="stylesheet" href="ressources/css/footer.css" />
    <link rel="stylesheet" href="ressources/css/sur-les-medias.css" />

</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->
        <main class="conteneur-principal">

            <section class='espace-ligne'></section>
            <h1 class="titre-page media">Les actualités et les évènements important du
                BUT et de l'IUT CY Paris Université dans les
                médias.</h1>

            <section class="colonne">
                <section class="zone-video">
                    <section class='espace-champ'></section>
                    <p class="titre-video">Le nouvelle réforme: le BUT MMI</p>
                    <iframe width="622px" height="389px" src="https://www.youtube.com/embed/oiEbQF7qfBU"></iframe>
                </section>

                <section class="zone-video">
                    <section class='espace-champ'></section>
                    <p class="titre-video">Pourquoi étudier à l'IUT CYU ?</p>
                    <iframe width="622px" height="389px" src="https://www.youtube.com/embed/SyjF4h2Zb7Q"></iframe>
                </section>
            </section>

            <section class='espace-ligne'></section>

            <section class="colonne">
                <section class="zone-video">
                    <section class='espace-champ'></section>
                    <p class="titre-video">Job interview en anglais <span class="titre-video"> au département MMI</span></p>
                    <iframe width="622px" height="389px" src="https://www.youtube.com/embed/t72pdxpNjyc"></iframe>
                </section>

                <section class="zone-video">
                    <section class='espace-champ'></section>
                    <p class="titre-video">L'importance de l'IUT dans <span class="titre-video"> les études supérieures </span></p>
                    <iframe width="622px" height="389px" src="https://www.youtube.com/embed/xD4wshE0hEg"></iframe>
                </section>

            </section>
    </section>

    <section class='espace-ligne'></section>

    </main>

    <section>
        <?php require_once('./ressources/includes/footer.php'); ?>
    </section>
</body>

</html>