<?php
$couleur_bulle_classe = "vert";
$page_active = "a-propos";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A propos</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/slide.css">
</head>

<body>

    <section class="conteneur-slide">
        <section class="slider milieu">
            <section class="slides">
                <input type="radio" name="radioo" id="r1" checked>
                <input type="radio" name="radioo" id="r2">
                <input type="radio" name="radioo" id="r3">
                <input type="radio" name="radioo" id="r4">

                <section class="slide s1">
                    <img src="ressources/images/notes.png" alt="notes">
                </section>

                <section class="slide s2">
                    <img src="ressources/images/absence.png" alt="absences et retards">
                </section>

                <section class="slide s3">
                    <img src="ressources/images/mails.png" alt="mails">
                </section>

                <section class="slide s4">
                    <img src="ressources/images/rendutravail.png" alt="travail">
                </section>

            <section class="navigation">
                <label for="r1" class="barre"></label>
                <label for="r2" class="barre"></label>
                <label for="r3" class="barre"></label>
                <label for="r4" class="barre"></label>
            </section>
        </section>
    </section>
    </section>

</body>

</html>