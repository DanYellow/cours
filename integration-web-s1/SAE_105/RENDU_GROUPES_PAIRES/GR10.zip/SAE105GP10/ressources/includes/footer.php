<section class="reseaux-sociaux">
    <section class="copyright c">
        <p>Certains textes sont issus de Wikipédia</p>
    </section>
    <ul>
        <li><a href="https://fr-fr.facebook.com/CYCergyParisUniversite/">Facebook</a></li>
        <li><a href="https://twitter.com/universitecergy?lang=fr">Twitter</a></li>
        <li><a href="https://www.cyu.fr/">Université CY Paris Université</a></li>
        <li><a href="#top" class="remonter li">• Remonter</a></li>
    </ul>
</section>


<section class="copyright"> 
    <p>© 2013–2021 - BUT MMI - CY Paris Université</p>

<img class="logo-cyu-couleur"
    src="./ressources/images/logo-cyu-couleur.svg"
    alt="Logo CYU en couleur">
</section>