<nav class="navigation-principale">
    <ul>
        <li><a href="./index.php" class="<?php if($page_active == "index") { echo "active";} ?>">ACCUEIL</a></li>
        <li><a href="./a-propos.php" class="<?php if($page_active == "a-propos") { echo "active";} ?>">A PROPOS</a></li>
        <li><a href="./contact.php"  class="<?php if($page_active == "contact") { echo "active";} ?>">CONTACT</a></li>
        <li><a href="./sur-les-medias.php" class="<?php if($page_active == "medias") { echo "active";} ?>">SUR LES MEDIAS</a></li>
        <li><a href="./application.php" class="<?php if($page_active == "application") { echo "active";} ?>">APPLICATION</a></li>
    </ul>
</nav>

<header class="bulle">
    <article class="titre">
        <h1 class="txt-grand">
            <span>Bachelor</span>
            <span>Universitaire de</span>
            <span>Technologie</span>
        </h1>
        <h2 class="txt-petit">
            <span>Métiers du Multimédia et de</span>
            <span>l'Internet</span>
        </h2>
    </article>

    <article class="bulle-icone <?php echo $couleur_bulle_classe; ?>"></article>
    <article class="bulle-icone-bordure <?php echo $couleur_bulle_classe; ?>"></article>
</header>