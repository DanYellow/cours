<?php
$couleur_bulle_classe = "vert";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ressources/css/style.css">
    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/a-propos.css">
    <link rel="icon" href="ressources\images\favicon.ico">
</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->
        <main class="conteneur-principal">
            <article class="cadrant">
                <pre class="b5"> Présentation 
 SAE 
 Exemple de SAE        
                </pre>
            </article>
            <p class="texte">Le BUT métiers du multimédia et de l'internet(mmi) remplace le Dut MMI à partir de 2021, auparavant appelé DUT SRC(services et réseaux de communication) jusqu'en mai2013, qui etait lancé a la rentrée universitaire 1994 par les IUT de Vélizy, Marne-la-vallée,
                Saint-raphael et verdun. Ce but offre une alternative aux anciens diplomes Bac+3,tels que la licence professionnelle en activités et techniques de communication et la licence professionnelle en système informatiques et logiciels. </p>
            <p class="texte2">Lorsque cette formation était proposée sous la forme d'un Diplome Universitaire Technologiques (dut),elle se deroulait sur deux années (1800 heures). En théorie, elle est accessible à tous les bacheliers, quelle que soit leur série. En moyenne, il y à de 30 à 35h de cours par semaine.
                Cette formation se divise en trois grands poles, auxquels il faut ajouter le projet tutoré (300heures) et les stages (420 heures). Les trois grands axes sont les suivants :
            </p>


            <ol class="liste1">
                <li>La culture contemporaine et langues étrangeres (500 heures)</li>
                <li>La culture scientifique et technique (700 heures)</li>
                <li>La culture communicationnelle (600 heures)</li>
            </ol>
            <article class="titre-image">

                <img src="ressources/images/imgscreen.png" alt="imageprinc" class="imageprinc">
                <H1 class="texte3">
                    <span> A CY Cergy Paris Université, il est donné la possibilité aux étudiants de passer un semestre au Québec à l'université du Québec à Chicoutimi (UQAC) dans une formation dont le contenu est proche de celui proposé à l'IUT. Il est également possible d'effectuer ce semestre après avoir été diplômé.<strong>Attention : les cours sont dispensés en langue Francaise.</strong>
                    </span>
                </H1>
                <h2 class="txt2">
                    <span>Situation d'apprentissage et d'évaluation</span>
                </h2>
                <p class="texte3">Dans l'optique de préparer au mieux les étudiants à leurs future vie professionnelle, les étudiants sont regroupés en agences de communication de 3 à 7 personnes dans des projets appelés "SAE" ou Situation d'Apprentissage et d'Evaluation. Ces agences ont pour but d'encourager le travail d'équipe dans un cadre reprenant l'environnement du travail en entreprise.</p>
                <P class="texte">La situation d'apprentissage et d'évaluation ou simplement SAE est la situation didactique que previlegie, au Québec, le Ministère de l'éducation, enseignement Supérieur et Recherche (MEESR) par le biais du Programme de fromation de l'école québécoise (PFEQ). Une SAE se definit comme un ensemble consituté d'une ou plusieurs tâches à réaliser par l'élève en vue d'atteindre le but fixé. Elle permet: à l'élève, de
                    developper et d'exercer une ou plusieurs compétences disciplinaires et transversales; à l'enseignant, d'assurer le suivi du développement des compétences dans une perspective d'aide à l'apprentissage. Elle est donc centrée sur l'élève et préconise une approche constructiviste ou socioconstructiviste à l'école.</P>
                <p class="texte">Les SAE sont une nouveauté des diplomes BUT,<strong>elles visent à remplacer les Devoirs Sur Table et les notes a terme,</strong>en proposant une approche plus "ingénieure" de la scolarité avec des études qui apprennent à résoudre des problémes et non plus apprendre par coeur leurs cours. </p>
                <h3 class="txt2">
                    <span>Exemples de projets réalisés en SAE</span>
                </h3>
            </article>
            <div class="conteneur">

                <article class="article">

                    <img src="ressources/images/imagetemoin.png" alt="element0" class="element0">
                    <article class="minititre">
                        <p> Reportage vidéo </p>
                        <p> SAE 101</p>
                    </article>
                    <article class="petit-texte">
                        <p>Apprendre les bases du reportage vidéo sur un sujet libre </p>
                    </article>
                </article>
                <article class="article">

                    <img src="ressources/images/imagetemoin.png" alt="element0" class="element0">
                    <article class="minititre">
                        <p> Reportage vidéo </p>
                        <p> SAE 101</p>
                    </article>
                    <article class="petit-texte">
                        <p>Apprendre les bases du reportage vidéo sur un sujet libre </p>
                    </article>
                </article>
                <article class="article">

                    <img src="ressources/images/imagetemoin.png" alt="element0" class="element0">
                    <article class="minititre">
                        <p> Reportage vidéo </p>
                        <p> SAE 101</p>
                    </article>
                    <article class="petit-texte">
                        <p>Apprendre les bases du reportage vidéo sur un sujet libre </p>
                    </article>
                </article>
                <article class="article">

                    <img src="ressources/images/imagetemoin.png" alt="element0" class="element0">
                    <article class="minititre">
                        <p> Reportage vidéo </p>
                        <p> SAE 101</p>
                    </article>
                    <article class="petit-texte">
                        <p>Apprendre les bases du reportage vidéo sur un sujet libre </p>
                    </article>
                </article>
                <article class="article">

                    <img src="ressources/images/imagetemoin.png" alt="element0" class="element0">
                    <article class="minititre">
                        <p> Reportage vidéo </p>
                        <p> SAE 101</p>
                    </article>
                    <article class="petit-texte">
                        <p>Apprendre les bases du reportage vidéo sur un sujet libre </p>
                    </article>
                </article>
                <article class="article">

                    <img src="ressources/images/imagetemoin.png" alt="element0" class="element0">
                    <article class="minititre">
                        <p> Reportage vidéo </p>
                        <p> SAE 101</p>
                    </article>
                    <article class="petit-texte">
                        <p>Apprendre les bases du reportage vidéo sur un sujet libre </p>
                    </article>
                </article>


                <footer class="bas">
                    <p>Certains textes sont issus de Wikipédia</p>
                    <p><a href="https://fr-fr.facebook.com/CYCergyParisUniversite/">Facebook</a> <a href="https://twitter.com/universitecergy?lang=fr">Twitter</a> <a href="https://www.cyu.fr/">Université CY Paris Université</a> • Remonter </p>
                    <img src="ressources/images/logo-iut.PNG" class="element2">
                    <p>© 2013–2021 - BUT MMI - CY Paris Université</p>
                    <div id="logo2"> </div>
                </footer>
        </main>

    </section>
</body>

</html>