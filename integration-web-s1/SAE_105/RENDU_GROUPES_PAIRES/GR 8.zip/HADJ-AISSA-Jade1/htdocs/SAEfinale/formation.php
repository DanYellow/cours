<?php

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/invent.css">
    <link rel="stylesheet" href="ressources/css/style.css">
    <link rel="icon" href="ressources/images/favicon.ico">
</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->
        <main class="conteneur-principal">
            <h1 class="titre-page">FORMATION</h1>
            <h2 class="titre-page2">Se former à l'Université, du B.U.T. au Doctorat</h2>

            <article>
                <p class="textes" id="texte1">
                    C'est fait ! A la rentrée 2021 le DUT devient le BUT (Bachelor Universitaire de technologie) : la formation passe de 2 à 3 ans.
                    Le BUT MMI (Métiers du Multimédia et de l’internet) est accessible après le Baccalauréat via Parcours Sup
                    et vous forme aux métiers du web. Les cours sont dispensés dans un IUT
                    (Institut Universitaire de Technologie) et mêlent enseignements généraux et techniques.</p>

                <p id="texte2">
                    Le titulaire de ce diplôme est associé aux activités de communication d'entreprise,
                    de création multimédia, de gestion de réseaux.
                    Le Bachelor Chef de Projet digital vous forme aux métiers du web en 3 ans avec une troisième année en spécialisation
                    (UX, UI, Motion Design ou Webmarketing).
                    Le Bachelor Chef de projet digital chez Digital Campus vous permettra de maîtriser les techniques et outils digitaux pour répondre à un besoin de visibilité,
                    de promotion ou de développement de l’activité d’un client interne ou externe. Cela implique à la fois la conception d’un dispositif digital adapté et fiable,
                    sa visibilité sur le web et la création de contenus attractifs.
                    le parcours stratégie de communication numérique et design d’expérience forme à la conception de supports de communication et
                    la prise en compte des aspects humains (facilité de navigation, ergonomie, visibilité sur le web ….).
                    Il prépare principalement aux métiers de chargés de communication numérique, d’UX designers,
                    de rédacteurs Web, de community manager,de spécialistes du référencement sur Internet …. Les principaux débouchés se situent en agences de communication, en agences Web,
                    ou dans les services de communication des entreprises.

                </p>

                <article class="conteneur">

                    <img src="ressources/images/mmi logo.jpg" class="element1"></div>
                    <img src="ressources/images/mmi logo.jpg" class="element2"> </div>

                    </div>
                </article>
                <p id="texte3">



                    Le parcours créativité numérique est consacré à l’expression d’un message sur différents médias, sous la forme de création graphique et d’écriture multimédia.
                    Il prépare principalement aux métiers de designers,
                    infographistes, game designers ou de techniciens audiovisuel. Les principaux débouchés se situent en agences de communication,
                    en agences Web, en agences publicitaires, ou dans les services de communication des grandes entreprises.
                    Le parcours développement web et dispositif interactif forme au développement de sites web et à l’intégration d’applications multimédia ou mobile.
                    Il prépare notamment aux métiers d’intégrateur ; de développeur back, front, ou Full stack ; d’intégrateur de dispositifs de la réalité virtuelle.
                    Les débouchés se situent en agences de communication,
                    en agences Web, dans des start-up ou des sociétés de services informatiques,
                    dans des services de communication des grandes entreprises ou organisations.
                </p>
                <article class="conteneur">
                    <img src="ressources/images/3805.jpg">
                    <img src="ressources/images/reussite.jpg">
                    <img src="ressources/images/contrat.jpg">
                </article>


                <p id="texte4">Le bachelor universitaire de technologie (BUT) est un diplôme national de l’enseignement supérieur. Il se prépare après le bac, en 6 semestres (3 ans) en IUT (institut universitaire de technologie), à temps plein ou en apprentissage. L’accès est sélectif. Les dossiers sont traités sur Parcoursup.

                    Le BUT sanctionne une formation générale et technologique (180 crédits ECTS) dans un domaine professionnel et confère le grade de licence.
                    Un DUT est délivré à l’issue des deux premières années afin de faciliter les passerelles vers d’autres formations.

                    Cette formation, de 2 000 heures d'enseignement en spécialités industrielles, 1 800 heures d'enseignement en spécialités tertiaires, alterne cours magistraux (CM),
                    travaux dirigés (TD) et travaux pratiques (TP) auxquels s’ajoutent 600 heures de projet tutoré, et de 22 à 26 semaines de stages en entreprise.

                    Le BUT se décline en 24 mentions correspondant à une branche d’activité professionnelle : informatique, carrières sociales, logistique et transport….
                    Certaines de ces spécialités peuvent comporter des parcours formant à des compétences spécifiques, plus pointues selon les métiers visés.
                    L’entrée dans ces parcours varie selon les spécialités de BUT. Généralement accessibles dès le 3ème semestre de la formation,
                    ils sont parfois proposés dès la 1ère année. Par ailleurs le programme des BUT peut être adapté localement selon les débouchés des différents territoires.</p>
            </article>
            <img src="ressources/images/amphi.jpg" class="img3">


            <footer class="bas">
                <p>Certains textes sont issus de Wikipédia</p>
                <p><a href="https://fr-fr.facebook.com/CYCergyParisUniversite/">Facebook</a> <a href="https://twitter.com/universitecergy?lang=fr">Twitter</a> <a href="https://www.cyu.fr/">Université CY Paris Université</a> • Remonter </p>
                <img src="ressources/images/logo-iut.PNG" class="element2"> </div>
                <p>© 2013–2021 - BUT MMI - CY Paris Université</p>
                <div id="logo2"> </div>
            </footer>
        </main>

    </section>


</body>

</html>