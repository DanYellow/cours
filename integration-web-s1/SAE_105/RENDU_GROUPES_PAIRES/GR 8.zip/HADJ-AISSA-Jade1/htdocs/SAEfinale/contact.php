<?php
$couleur_bulle_classe = "jaune";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="stylesheet" href="ressources/css/style.css">
    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="icon" href="ressources/css/favicon.ico">
</head>


<body>
    <?php


 
    if(isset($_POST['submit'])){
        if (empty($_POST['e-mail']) || empty($_POST['Nom']) || empty($_POST['Prenom'])) {
            echo "<p class='formulaire' style='font-size : 30px; text-align: center; background-color:rgb(239 156 156); color:#931e1e; height: 40px;'>Tous les champs doivent être remplis pour soumettre le formulaire !</p>";
        } else{
            echo "<p class='formulaire' style='font-size : 30px; text-align: center; background-color:#D4EDDA; color: #086c08; height: 40px;'>Message envoyé</p>";
        }
    }





    ?>





    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>

        <main class="conteneur-principal">
            <p class="Info">Plus d'infos sur la formation ?<br>Contactez-nous !</p>

            <p class="Info2"><span style="font-weight:900">La formation s'ouvre à tous les bacheliers,</span>pour rappel. Avoir des connaissances en programmation, design ou encore audiovisuel n'est pas
                obligatoire mais reste un bon atout, car il faut aimer la curiosité dans cette formation pluridisciplinaire.<span style="font-weight:900"> Il est également possible de faire la
                    formation après une reprise d'études ou une réorientation.</span></p>

            <p class="Contacter">Nous contacter en ligne</p>


            <form action="contact.php" method="post">


                <legend>Prénom*</legend>
                <input type="text" class="case1" name="Prenom" placeholder="Ex : John" size="30" maxlength="60" />
                <legend>Nom de famille*</legend>
                <input type="text" class="case1" name="Nom" placeholder="Ex : Dupont" size="30" maxlength="60" />
                <legend>Adresse e-mail*</legend>
                <input type="email" class="case1" name="e-mail" placeholder="Ex : exemple@gmail.com" size="30" maxlength="60" />
                <legend>Message</legend>

                <textarea class="message" name="Message" id="Message" cols="112" rows="20"></textarea>




                <p class="petittexte"> Je suis </p>

                <div>
                    <input type="radio" class="case" id="case1" name="groupe1" value="case 1" checked>
                    <label for="case1" class="caseT">Je ne souhaite pas le préciser</label>

                    <input type="radio" class="case" id="case2" name="groupe1" value="case 2">
                    <label for="case2" class="caseT">Étudiant / Étudiante</label>

                    <input type="radio" class="case" id="case3" name="groupe1" value="case 3">
                    <label for="case3" class="caseT">Parent</label>

                    <input type="radio" class="case" id="case4" name="groupe1" value="case 4">
                    <label for="case4" class="caseT">Autre</label>

                </div>



                <p><input type="submit" name="submit" class="submit" value="ENVOYER"></p>


            </form>


            <p class="champs">* champs obligatoire</p>



            <p class="Contacter2">Nous contacter par courrier</p>

            <p class="Couriel">
                IUT de Cergy-Pontoise,<br>
                Département Métiers du Multimédia et de l’Internet (MMI)<br>
                34 Bis Boulevard Henri Bergson<br>
                95200 Sarcelles
            </p>


    <footer class="bas">
                <p>Certains textes sont issus de Wikipédia</p>
                <p><a href="https://fr-fr.facebook.com/CYCergyParisUniversite/">Facebook</a> <a href="https://twitter.com/universitecergy?lang=fr">Twitter</a> <a href="https://www.cyu.fr/">Université CY Paris Université</a> • Remonter </p>
                <img src="ressources/images/logo-iut.PNG" class="element2">
                <p>© 2013–2021 - BUT MMI - CY Paris Université</p>
                <div id="logo2"> </div>
            </footer>
            </section>

    </main>




</body>

</html>