<?php
$couleur_bulle_classe = "rose";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/Jade-accueil.css">
    <link rel="stylesheet" href="ressources/css/style.css">
    <link rel="icon" href="ressources/images/favicon.ico">
</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('./ressources/includes/header.php'); ?>


        <!-- Vous allez principalement écrire votre code HTML ci-dessous -->


        <main class="conteneur-principal">

            <h1 class="titre-page">Articles sur le BUT MMI</h1>

            <section class="colonne">
                <div class="container">
                    <article class="article1">

                        <img src="ressources/images/Capture.PNG" alt="photo1" class="photo1">

                        <h1 class="txt-grand1">
                            Développement Web
                        </h1>

                        <p class="txt-petit"> Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML. On y apprend les langages HTML et CSS, simples mais énormément pratiques. Le web ayant été pensé pour être accessible, le cours enseigne également les normes d'accessibilités comme le contraste des couleurs ou encore la taille des polices d'écriture.</p>


                    </article>

                    <article class="article1">

                        <img src="ressources/images/Capture.PNG" alt="photo1" class="photo1">

                        <h2 class="txt-grand1">
                            Développement Web
                        </h2>

                        <p class="txt-petit"> Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML. On y apprend les langages HTML et CSS, simples mais énormément pratiques. Le web ayant été pensé pour être accessible, le cours enseigne également les normes d'accessibilités comme le contraste des couleurs ou encore la taille des polices d'écriture.</p>


                    </article>

                    <article class="article1">

                        <img src="ressources/images/Capture.PNG" alt="photo1" class="photo1">

                        <h1 class="txt-grand1">
                            Développement Web
                        </h1>

                        <p class="txt-petit"> Initier les étudiants et les étudiantes aux bases de la programmation de pages HTML. On y apprend les langages HTML et CSS, simples mais énormément pratiques. Le web ayant été pensé pour être accessible, le cours enseigne également les normes d'accessibilités comme le contraste des couleurs ou encore la taille des polices d'écriture.</p>


                    </article>

                </div>
                <a class="jpo-banniere" href="https://www.cyu.fr/salons-journee-portes-ouvertes">
                    <img src="ressources/images/logo-cyu-blanc.png" width="200" class="logo" alt="">

                    <section class="textes">
                        <p class="txt-petit">Journée portes <br /> ouvertes</p>
                        <p class="txt-grand">
                            12/02/2022, <br />
                            de 10h à 17h
                        </p>
                        <p class="en-savoir-plus">EN SAVOIR PLUS</p>
                    </section>
                </a>
            </section>


<footer class="bas">
    <p>Certains textes sont issus de Wikipédia</p>
    <p><a href="https://fr-fr.facebook.com/CYCergyParisUniversite/">Facebook</a> <a href="https://twitter.com/universitecergy?lang=fr">Twitter</a> <a href="https://www.cyu.fr/">Université CY Paris Université</a> • Remonter </p>
    <img src="ressources/images/logo-iut.PNG" class="element2">
    <p>© 2013–2021 - BUT MMI - CY Paris Université</p>
    <div id="logo2"> </div>
    </main>

</section>
</body>
</footer>

</html>