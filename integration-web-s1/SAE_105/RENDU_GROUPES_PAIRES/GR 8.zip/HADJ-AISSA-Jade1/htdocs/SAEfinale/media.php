<?php
$couleur_bulle_classe = "rouge";
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ressources/css/style.css">
    <link rel="stylesheet" href="ressources/css/reset.css">
    <link rel="stylesheet" href="ressources/css/global.css">
    <link rel="stylesheet" href="ressources/css/header.css">
    <link rel="stylesheet" href="ressources/css/accueil.css">
    <link rel="stylesheet" href="ressources/css/media.css">
    <link rel="icon" href="ressources/images/favicon.ico">
</head>

<body>
    <section class="conteneur-1280">
        <?php require_once('ressources/includes/header.php'); ?>



        <main class="conteneur-principal">
            <h1 class="titre-page">Les actualités et les évènements important du BUT et de l'IUT CY Paris Université dans les médias</h1>

            <div class="container-video">
                <article class="video">
                    <p class="titre">La nouvelle réforme: le BUT MMI</p>
                    <iframe class="video-yt" src="https://www.youtube.com/embed/oiEbQF7qfBU" frameborder="0" gesture="media" height="315" allowfullscreen></iframe>
                </article>

                <article class="video">
                    <p class="titre">Pourquoi étudier à l'IUT CYU ?</p>
                    <iframe class="video-yt" src=https://www.youtube.com/embed/SyjF4h2Zb7Q frameborder="0" gesture="media" height="315" allowfullscreen></iframe>
                </article>


                <article class="video">
                    <p class="titre">Job interview en anglais au département MMI</p>
                    <iframe class="video-yt" src=https://www.youtube.com/embed/t72pdxpNjyc frameborder="0" gesture="media" height="315" allowfullscreen></iframe>
                </article>

                <article class="video">
                    <p class="titre">L'importance de l'IUT dand les études supérieures</p>
                    <iframe class="video-yt" src=https://www.youtube.com/embed/xD4wshE0hEg frameborder="0" gesture="media" height="315" allowfullscreen></iframe>
                </article>

            </div>
            </a>

<footer class="bas">
    <p>Certains textes sont issus de Wikipédia</p>
    <p><a href="https://fr-fr.facebook.com/CYCergyParisUniversite/">Facebook</a> <a href="https://twitter.com/universitecergy?lang=fr">Twitter</a> <a href="https://www.cyu.fr/">Université CY Paris Université</a> • Remonter </p>
    <img src="ressources/images/logo-iut.PNG" class="element2">
    <p>© 2013–2021 - BUT MMI - CY Paris Université</p>
    <div id="logo2"> </div>

    </main>
    </section>
</body>
</footer>

</html>