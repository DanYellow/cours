let message = "hello World";
let nombre = 2;

console.log(message + nombre); // operateur + est une concaténation (variables de type string et number)


let nombre1 = 1; 
let nombre2 = 2;

console.log(message + nombre); // operateur + est une addition (variables de type number)



console.log(nombre1/0); // qu'est ce le type du resultat nombre1/0 ? 
