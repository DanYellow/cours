alert("Hello World!") // affiche une fenetre alert dans le navigateur.

console.log("Hello World!"); // affiche un log (message) dans la console du navigateur.
