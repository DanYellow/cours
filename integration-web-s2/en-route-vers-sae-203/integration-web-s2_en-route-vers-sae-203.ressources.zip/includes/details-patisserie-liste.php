<li class='patisserie'>
    <figure>
        <img src='ressources/images/patisseries/financiers.jpg' alt=''>
    </figure>
    <section class='details'>
        <section class='textes'>
            <p class='titre'>Madeleines</p>
            <p class='prix'>8 euros la demi-douzaine</p>
        </section>
        <section class='liste-boutons'>
            <button type='button' class='cta-primaire'>Ajouter au panier</button>
            <a href='' class='cta-secondaire'>Voir plus d'infos</a>
        </section>
    </section>
</li>