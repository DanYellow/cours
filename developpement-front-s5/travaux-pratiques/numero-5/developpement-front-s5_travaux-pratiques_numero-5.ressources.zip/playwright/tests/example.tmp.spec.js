// @ts-check
// const { test, expect } = require("@playwright/test");
import path from "path";
import { fileURLToPath } from "url";
import { test, expect } from "@playwright/test";

test("has title", async ({ browser, context }) => {
    const page = await browser.newPage();
    // test.setTimeout(10000);

    // await page.setViewportSize({
    //     width: 640,
    //     height: 480,
    // });

    // await context.addCookies([
    //     { name: "sessionid", value: "random", path: "/", domain: "localhost" },
    // ]);

    await page.goto("/");

    // console.log(await context.cookies());
    await page.route("/api", async (route) => {
        // await route.fulfill({
        //     status: 404,
        //     contentType: 'application/json',
        //     body: JSON.stringify({ name: "Strawberry", id: 21 })
        //   });
        if (route.request().method().toLowerCase() === "get") {
            const json = [{ name: "Strawberry", id: 21 }];
            await route.fulfill({ json });
        } else {
            route.continue();
        }
    });

    // await page.waitForResponse("/api");

    let fooRequestWasMade = false;

    page.on("request", (request) => {
        if (request.url().includes("/foobar/")) fooRequestWasMade = true;
    });

    expect(fooRequestWasMade).toBe(false);

    // Expect a title "to contain" a substring.
    await page.locator("input").nth(0).fill("tetes");

    await page
        .locator("input")
        .nth(10)
        .evaluate((item) => {
            item.style.display = "none";
        });

    await page.screenshot({ path: "screenshot.tmp.png" });

    // await page.getByTestId('upload').setInputFiles('./tests/test.tmp.gif'); ""
    // await page.getByTestId('upload').setInputFiles(path.join(__dirname, 'test.tmp.gif'));
    // await page.locator("input").nth(1).fill("tetes11");
    // await page.locator("input").nth(2).fill("2");
    // await page.locator("input").nth(3).fill("10");
    // await page.locator("input").nth(4).fill("12");
    // await page.locator("input").nth(5).fill("14");
    // await page.locator("input").nth(6).fill("18");
    // await page.locator("#parcours").selectOption("dev");
    // await page.locator("input").nth(1).press("Enter");
    // await page.locator("input").nth(1).press("Enter");

    // for (const li of await page.getByRole('textbox').all())
    //     await console.log(li);
    // await page.getByRole("form").press("Enter");
    //   await page.getByRole("textbox").fill("tetes")
    // await expect(page.getByRole("textbox").first()).toHaveClass("w-1/2");

//     await page.goto("https://danyellow.net/");
//     const foo = page.getByRole("link").last();
//     foo.click()

//     const pagePromise = context.waitForEvent('page');
//     const newPage = await pagePromise;
// ""
//     // console.log(await page.url())
    
//     // await page.waitForURL("https://github.com/DanYellow");
//     console.log(await newPage.url())

//     await expect(newPage).toHaveURL(/example/);

});

test("Visit university's website", async ({ page, context }) => {
    test.setTimeout(10000);
    await page.goto("https://danyellow.net/index2.html");
    const foo = page.getByRole("textbox").last();
    await foo.click()



    // const pagePromise = context.waitForEvent('page');
    // const newPage = await pagePromise;

    // console.log(await newPage.url())
    // await page.goto('http://example.com');
    // await page.waitForURL(/https:\/\/github.com\/DanYellow/i);
    console.log(await page.url())
    await expect(page).toHaveURL(/https:\/\/github.com\/DanYellow/i);

    // context.on('page', async page2 => {
    //     await page2.waitForLoadState();
    //     console.log(await page2.title());
    //   });


    // await expect.soft(page).toHaveScreenshot();
    // await page.screenshot({ path: "screenshot.png" });
    // console.log(await page.title())
    // await expect(page).toHaveTitle(/cergy/i);
    // await expect(page).toHaveTitle(/^[A-Z]/i);
    // console.log(await page.title());
    // console.log(Object.values(foo))   await expect(page).toHaveURL('https://website.com/login/');
});

test("multi domains", async ({ page, context }) => {
    // test.setTimeout(10000);
    // const pageOne = await context.newPage();
    const pageTwo = await context.newPage();

    await page.goto(
        "https://fr.wikipedia.org/wiki/Wikip%C3%A9dia:Accueil_principal"
    );

    await page.locator(".cdx-text-input__input").first().fill("hello");
    await page.locator(".cdx-text-input__input").first().press("Enter");
    await expect(page).toHaveURL(/hello/i);

    await pageTwo.goto(
        "https://www.cyu.fr/"
    );
    const foo = pageTwo.locator(".news-card__link").first();
    await foo.click();
    await expect(pageTwo.locator(".dates")).toBeVisible();
    // await page.getByRole("textbox").first().fill("hello");
    // await page.goto("http://localhost:3000/");
    // const foo = page.getByRole("link").last();
    // // const foo = page.locator(".news-card__link").first()

    // await foo.click({ force: true });
    // await page.waitForURL('https://www.cyu.fr/')
    // console.log(Object.values(foo))   await expect(page).toHaveURL('https://website.com/login/');
});


test("local", async ({ page, context }) => {
    // test.setTimeout(10000);
    // const pageOne = await context.newPage();
    const pageTwo = await context.newPage();

    await page.goto(
        "index.html"
    );

    // await page.getByRole("textbox").first().fill("hello");
    // await page.goto("http://localhost:3000/");
    // const foo = page.getByRole("link").last();
    // // const foo = page.locator(".news-card__link").first()

    // await foo.click({ force: true });
    // await page.waitForURL('https://www.cyu.fr/')
    // console.log(Object.values(foo))   await expect(page).toHaveURL('https://website.com/login/');
});
