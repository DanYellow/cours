export default {
  // config options
};
