const classForType = {
    "plante": "bg-green-100",
}

export { classForType }