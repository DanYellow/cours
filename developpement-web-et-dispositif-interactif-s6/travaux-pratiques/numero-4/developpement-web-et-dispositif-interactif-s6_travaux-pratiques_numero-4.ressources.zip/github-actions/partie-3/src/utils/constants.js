export const NB_NUMBER_INTEGERS_PKMN_ID = 4;
export const HTTP_NOT_FOUND_CODE_ERROR = 404;
export const POPOVER_ERRORS = {
    unknown_pkmn: "unknown_pkmn",
    lost_connection: "lost_connection",
    unknown: "unknown",
}

export const CUSTOM_EVENTS = {
    startLoading: "startloading",
    endLoading: "endloading",
}
