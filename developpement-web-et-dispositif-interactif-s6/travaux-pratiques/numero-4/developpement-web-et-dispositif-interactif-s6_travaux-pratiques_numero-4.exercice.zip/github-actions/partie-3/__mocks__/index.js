export { default as pokedex } from "./pokedex";
export { default as evolutionLine } from "./evolutionline";
export { default as evolutionLineFr } from "./evolutionline.fr";
