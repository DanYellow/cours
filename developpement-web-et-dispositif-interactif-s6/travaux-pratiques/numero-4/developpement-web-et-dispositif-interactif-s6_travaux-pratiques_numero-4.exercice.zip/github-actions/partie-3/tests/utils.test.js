import { expect, describe, it, vi } from 'vitest';
import { Window } from 'happy-dom';

import { getVersionForName, cleanString, getEvolutionChain, replaceImage } from "#src/utils/index.js";
import { evolutionLine, evolutionLineFr, pokedex } from "#mocks/index.js";

const window = new Window({ url: 'https://localhost:5173' });
const document = window.document;

describe("getVersionForName", () => {
    it("should return black version", () => {
        expect(getVersionForName["ruby"]).toBe("Pokémon Rubis");
    });
});

describe("cleanString", () => {
    it("should remove all accents and lowercase string", () => {
        expect(cleanString("Stéphane")).toBe("stéphane");
    });
});

describe("getEvolutionChain", () => {
    it("should not return more than three levels of evolutions", () => {
        const res = getEvolutionChain(
            evolutionLine,
            evolutionLineFr,
            pokedex
        )

        expect(res.length).toBeLessThan(4);
        expect(res[0].length).toBeLessThan(4);
    });

    it("should return a nested array", () => {
        const res = getEvolutionChain(
            evolutionLine,
            evolutionLineFr,
            pokedex
        );

        res.forEach((item) => {
            expect(Array.isArray(item)).toBeTruthy();
        });
    });
});

describe("replaceImage", () => {
    it("should call twice the function", () => {
        const img = document.createElement("img");
        const fn = vi.fn()
        replaceImage(img, "test", fn)
        console.log(img);

        expect(fn).toBeCalled();
    });
});


