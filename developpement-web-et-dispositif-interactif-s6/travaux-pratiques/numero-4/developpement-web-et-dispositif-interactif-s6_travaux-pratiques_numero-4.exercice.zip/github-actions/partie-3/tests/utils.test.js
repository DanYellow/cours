import { expect, describe, it, vi } from "vitest";

import {
    getVersionForName,
    cleanString,
    getEvolutionChain,
    replaceImage,
} from "#src/utils/index.js";

import { evolutionLine, evolutionLineFr, pokedex } from "#mocks/index.js";
import { cp } from "fs";

describe("getVersionForName", () => {
    it("should return black version", () => {
        expect(getVersionForName["ruby"]).toMatch(/rubis/i);
    });
});

describe("cleanString", () => {
    it("should remove all accents and lowercase string", () => {
        expect(cleanString("Stéphane")).toBe("stéphane");
    });
});

describe("getEvolutionChain", () => {
    it("should not return more than three levels of evolutions", () => {
        const res = getEvolutionChain(evolutionLine, evolutionLineFr, pokedex);

        expect(res.length).toBeLessThan(4);
        expect(res[0].length).toBeLessThan(4);
    });

    it("should return a nested array", () => {
        const res = getEvolutionChain(evolutionLine, evolutionLineFr, pokedex);

        // global.Image = class {
        //     constructor() {
        //       setTimeout(() => {
        //         console.log("xxxxaaa");
        //         // this.onload(); // simulate success
        //       }, 100);
        //     }
        //   }
        const img = document.createElement("img");
        replaceImage(img, "fake.img", () => {
            console.log("fffffe");
        });

        waitForImage(img).then(loadedImage => {
            console.log("123456")
          })

        res.forEach((item) => {
            expect(Array.isArray(item)).toBeTruthy();
        });
    });
});


function waitForImage(img) {
    return new Promise(resolve => {
      img.onload = () => resolve(img)
    })
  }
