using UnityEngine;

/**
* Script just for Inspector
* DO NOT EDIT
**/
public class ReadOnlyInspectorAttribute : PropertyAttribute
{

}