Proposez une alternative au carrousel de la partie "vous aimerez aussi" (il faut défiler un peu) affiché sur la fiche recette du site  [cestmeilleurquandcestbon.com](https://cestmeilleurquandcestbon.com/f/a-la-maison/la-meilleure-puree-du-monde/).

Cette alternative doit être valable sur PC et terminaux mobiles. Prenez bien en considération les spécificités de ces terminaux pour proposer la meilleure expérience utilisateur possible. 

Si vous l'estimez nécessaire, vous pouvez également afficher des informations supplémentaires.