<footer class="pied-de-page">
    <section class="conteneur">
        <section class="contenu">
            <h1>Salon de thé de l'IUT</h1>
            <p>© 2021–2022 - BUT MMI - En route vers la SAÉ 203</p>
        </section>
    </section>
</footer>