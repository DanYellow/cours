### Données pour la période du 01/04/2024 au 30/06/2024
Taux de réussite à l'échelle du Val-d'Oise - Première présentation (permis B) : 0.586104
Taux de réussite à l'échelle du Val-d'Oise - Première + énième présentation (permis B) : 0.595742