Observez l'image suivante :

![Alt text](parking.jpg "a title")

Proposez une alternative plus appropriée pour les utilisateurs. 
Des lois UX comme celle de la simplicité peuvent vous aider : [https://uxmag.medium.com/how-to-simplify-your-design-80d2a4ebf057](https://uxmag.medium.com/how-to-simplify-your-design-80d2a4ebf057)