Définissez l'interface d'un site web résumant les parties et accomplissements (durant une partie) d'un joueur dans le cadre d'un jeu vidéo coopératif dans lequel le joueur doit affronter une horde d'ennemies.

A vous de définir les différentes statisques que vous souhaitez affichez (nombre de parties, nombre d'ennemis éliminés...).