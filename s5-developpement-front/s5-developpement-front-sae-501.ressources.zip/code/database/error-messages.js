export const errorRequiredMessage = (title = "un champ") => {
    return `Veuillez mettre ${title}, le champ ne peut pas être nul ou vide`;
};
