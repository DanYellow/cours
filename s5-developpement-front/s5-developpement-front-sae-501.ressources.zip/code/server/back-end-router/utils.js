export const ressourceNameInApi = {
    authors: "authors",
    articles: "articles",
    saes: "saes",
};
