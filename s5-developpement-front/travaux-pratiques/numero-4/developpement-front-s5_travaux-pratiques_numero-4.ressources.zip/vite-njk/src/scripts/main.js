import '/src/styles/style.css'
import '/src/styles/header.css'

console.log(import.meta.env.VITE_HELLO)
